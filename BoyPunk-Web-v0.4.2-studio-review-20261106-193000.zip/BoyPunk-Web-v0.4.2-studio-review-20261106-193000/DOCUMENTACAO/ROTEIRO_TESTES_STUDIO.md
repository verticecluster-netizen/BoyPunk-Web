# ROTEIRO DE TESTES DE AVALIAÇÃO — STUDIO QA (v0.4.2)
======================================================

**Build:** `BoyPunk-Web-v0.4.2-studio-review-20261106-193000`  
**Objetivo:** Validar game feel, controles, consistência visual, áudio e estabilidade para direcionar as próximas etapas de desenvolvimento.

---

## BATERIA 1: CONTROLES E MOVIMENTAÇÃO (A/D & RESPOSTA FÍSICA)
- [ ] **1.1. Troca Rápida de Direção (A ↔ D):**
  - Pressione `A` para andar à esquerda; mantendo `A`, pressione `D`. O personagem deve virar imediatamente à direita.
  - Ao soltar `D` (mantendo `A`), o personagem deve retornar imediatamente à esquerda sem parada morta.
  - Repita o teste com as setas `←` e `→`.
- [ ] **1.2. Soltar Teclas e Atrito:**
  - Em velocidade máxima, solte todas as teclas direcionais. Verifique se o personagem desacelera suavemente por inércia/atrito até `vx = 0`.
- [ ] **1.3. Perda e Recuperação de Foco (Alt+Tab / Blur):**
  - Mantendo `A` ou `D` pressionado, clique fora da janela do navegador ou aperte `Alt+Tab`. Ao retornar o foco, o personagem NÃO deve continuar andando sozinho.
- [ ] **1.4. Tiro em Movimento com Botão Esquerdo:**
  - Corra pressionando `D` e efetue cliques contínuos com o botão esquerdo do mouse no Canvas. Confirme que o personagem dispara para a frente sem travar o passo de corrida.

---

## BATERIA 2: MENUS, INTERFACE E NAVEGAÇÃO
- [ ] **2.1. Confirmação Universal:**
  - Navegue pelos menus usando setas / D-pad e confirme opções com `Enter`, `Espaço`, clique do mouse e botão Sul do gamepad.
- [ ] **2.2. Prevenção de Repetição (Key Repeat):**
  - Mantenha `Enter` ou `Espaço` pressionado sobre o botão de iniciar. O jogo deve registrar um único clique, sem disparar transições repetitivas em loop.
- [ ] **2.3. Pausa e Retomada (`Esc` / `Start`):**
  - Pressione `Esc` durante a partida. Confirme que todos os inimigos, cronômetros, partículas e áudios pausam imediatamente.
  - Despause e confirme que nenhuma entidade sofre teletransporte ou duplicação.

---

## BATERIA 3: MODO CAMPANHA E TRANSIÇÕES
- [ ] **3.1. Distrito Neon (Fase 1):**
  - Elimine Chasers e colete almas (bolhas ciano brilhantes).
  - Aproxime-se do Altar central e pressione `E` para depositar.
  - Verifique se a barra de integridade do Altar reage e se a contagem atinge a meta de vitória.
- [ ] **3.2. Transição para a Câmara de Energia (Fase Bônus):**
  - Ao vencer o Distrito com qualificação, confirme a transição para a Câmara de Energia.
  - Observe a contagem regressiva de 20 segundos e a telegrafia do Canhão Laser (linha vermelha e mira travada antes do disparo).
  - Verifique os Chasers de 3 HP (com feedback de `hurtFlash` ao receber tiros).
- [ ] **3.3. Transição para a Fábrica de Sucata (Fase 2):**
  - Ao concluir a Câmara, confirme o carregamento da Fábrica de Sucata.
  - Inspecione a névoa, a movimentação dos pistões hidráulicos e a presença de fundo do Factory Overlord.

---

## BATERIA 4: MODO SOBREVIVÊNCIA (SOLO & CO-OP)
- [ ] **4.1. Seleção de Protagonistas:**
  - Inicie Sobrevivência solo com **BoyPunk** e depois com **Nilo**.
  - Confirme as diferenças táteis: cadência de tiro, recuo e sons distintos.
- [ ] **4.2. Power-ups e Regras de Coleta:**
  - **Tiro Rápido (TR):** Acelera a cadência de fogo por 10 segundos.
  - **Rajada Dupla (RD):** Emite 2 projéteis por disparo. Colete TR e RD juntos e avalie o poder de fogo.
  - **Escudo Tático (ES):** Concede proteção contra 1 golpe. Ao sofrer dano, confirme que a vida não diminui e o escudo se dissipa.
  - **Cura (CU):** Com 4/4 de HP, passe por cima do ícone de Cura: ele NÃO deve ser consumido. Sofra 1 de dano (ficando 3/4) e passe novamente: o ícone deve ser consumido, recuperando a vida para 4/4.
  - **Reaparecimento (Respawn):** Verifique se os power-ups reaparecem em seus pedestais após o tempo determinado (18 a 30 s).
- [ ] **4.3. Sobrevivência Co-op Local:**
  - Inicie `?coop-survival=1`.
  - Controle P1 e P2 simultaneamente. Confirme que ambos possuem painéis de status dedicados e que a derrota só ocorre após a queda de ambos os jogadores.

---

## BATERIA 5: ÁUDIO, MUTE E ESTABILIDADE
- [ ] **5.1. Desbloqueio e Mute:**
  - O áudio inicia somente após o primeiro clique (conformidade Web Audio).
  - Pressione o botão de Mute no HUD/Menu e confirme que todo o som é silenciado instantaneamente sem estalos ou ruídos residuais.
- [ ] **5.2. Timbre de Disparo por Personagem:**
  - Disparos de BoyPunk: timbre agudo sintetizado (onda triangle/pulse).
  - Disparos de Nilo: timbre grave robusto (onda sawtooth).
- [ ] **5.3. Derrota e Retry Limpo:**
  - Deixe o personagem perder todos os pontos de vida.
  - Confirme a tela de Game Over e clique em "Tentar Novamente".
  - Verifique se a nova partida inicia sem lentidão, vazamento de memória ou acúmulo de inimigos antigos.
