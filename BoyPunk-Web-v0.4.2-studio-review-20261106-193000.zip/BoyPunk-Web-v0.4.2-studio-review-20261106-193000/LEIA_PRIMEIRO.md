# BOYPUNK! WEB — PACOTE DE AVALIAÇÃO STUDIO (v0.4.2)
======================================================

**Identificação da Build:** `BoyPunk-Web-v0.4.2-studio-review-20261106-193000`  
**Data da Build:** 2026-11-06 19:30 BRT  
**Versão autoritativa:** `0.4.2` (declarada em `src/version.js` e `package.json`)  
**Público-alvo:** Equipe de QA, Design e Produção do Studio.

---

## 1. COMO ABRIR O JOGO

Este pacote oferece **duas formas de execução**:

### OPÇÃO A: JOGAR.html (Autocontido / Standalone Offline — Recomendado para Teste Rápido)
1. Dê um duplo clique no arquivo `JOGAR.html` na raiz desta pasta, ou abra-o diretamente em qualquer navegador moderno (Chrome, Edge, Firefox, Safari).
2. Não requer instalação, Node.js, Python ou servidor local.
3. Todo o código, estilos, fontes, sprites e efeitos sonoros estão embutidos no próprio arquivo HTML.
4. Clique na tela para desbloquear o áudio Web Audio.

### OPÇÃO B: Pacote WEB com Servidor Local (Fidelidade Máxima / Inspeção de Rede)
Se você estiver em ambiente Linux/macOS com Node.js ou desejar inspecionar o carregamento modular:
1. Abra um terminal na pasta `WEB/`:
   ```bash
   cd WEB
   ./iniciar-jogo.sh
   ```
2. Ou via Node.js puro:
   ```bash
   node tools/server.mjs --host 127.0.0.1 --port 47831 --root .
   ```
3. Acesse `http://127.0.0.1:47831/` no navegador.

---

## 2. REQUISITOS DO SISTEMA
- Navegador moderno com suporte a HTML5 Canvas 2D, ES6 Modules (para opção WEB) e Web Audio API.
- Teclado padrão (QWERTY/ABNT), Mouse com botão esquerdo ou Gamepad/Joystick compatível com a Gamepad API do navegador (Xbox, DualShock/DualSense ou genérico XInput/DirectInput).
- Resolução recomendada de tela: mínimo 960×540 (o jogo roda em 480×270 lógico com escala pixel-perfect 1x/2x adaptável).

---

## 3. CONTROLES REAIS DE JOGABILIDADE

### Teclado (Jogador 1 / Solo)
- **Mover para Esquerda / Direita:** `A` / `D` ou Setas direcionais `←` / `→`.
  *(Nota técnica: o sistema de input resolve a direção física mais recente, permitindo trocas ágeis A/D sem perda de movimento).*
- **Pulo e Salto Duplo:** `W`, Seta para cima `↑` ou tecla `Espaço`.
- **Ataque / Tiro:** `J`, `X`, `F` ou **Botão Esquerdo do Mouse** no Canvas.
- **Depositar Almas (no Altar da Campanha):** `E`.
- **Habilidade Própria (Nilo - Cura Própria):** Tecla `H` ou botão dedicado do HUD.
- **Pausa / Retomar:** Tecla `Esc`.
- **Navegação de Menus:** Teclas `Enter`, `Espaço`, Clique do Mouse ou D-pad/Botão A do Gamepad.

### Gamepad / Joystick
- **Mover:** D-pad Esquerda/Direita ou Analógico Esquerdo.
- **Pulo:** Botão Sul (`A` no Xbox / `✕` no PlayStation).
- **Ataque:** Botão Oeste (`X` no Xbox / `▢` no PlayStation) ou Gatilho Direito (`RT`/`R2`).
- **Depositar Almas:** Botão Norte (`Y` no Xbox / `△` no PlayStation).
- **Habilidade (Nilo):** Botão Leste (`B` no Xbox / `◯` no PlayStation).
- **Pausa:** Botão `Start` / `Options`.

---

## 4. COMO INICIAR O MODO COOPERATIVO (CO-OP)

O jogo possui suporte a dois jogadores locais (Solo/Preview e Modo Sobrevivência Co-op):
1. **Campanha / Preview Co-op:**
   - Na tela inicial, utilize o atalho de URL `?coop=1` ou selecione o modo cooperativo no menu principal quando disponível.
   - P1 controla **BoyPunk** (Teclado/Mouse ou Gamepad 1).
   - P2 controla **Nilo** (Gamepad 2 ou layout secundário).
2. **Modo Sobrevivência Co-op Local:**
   - Inicie o jogo adicionando o parâmetro `?coop-survival=1` ou pelo menu de modos em "Sobrevivência Co-op".
   - Ambos os protagonistas combatem na mesma arena com vidas separadas e coleta de suporte compartilhada com desempate alternado por spawn.

---

## 5. MODOS DISPONÍVEIS NESTA BUILD

1. **Modo Campanha (3 Fases):**
   - **Fase 1: Distrito Neon:** Colete e deposite almas no Altar central enquanto defende a estrutura de hordas inimigas.
   - **Fase Bônus: Câmara de Energia:** Fase vertical de 20 segundos com canhão laser telegrafado, plataformas sólidas/one-way e pressão móvel de Chasers de 3 HP.
   - **Fase 2: Fábrica de Sucata:** Ambiente industrial com hazards de pistões hidráulicos, névoa tóxica e o imponente Factory Overlord ao fundo.
2. **Modo Sobrevivência (Solo e Co-op):**
   - Sobreviva contra ondas infinitas de Chasers e Patrol Shooters. Quatro spawns fixos de power-ups regeneram em ciclos estáveis:
     - **Tiro Rápido (TR):** Reduz o cooldown de disparo por 10 segundos.
     - **Rajada Dupla (RD):** Dispara projéteis duplos por 10 segundos (combina perfeitamente com TR!).
     - **Escudo Tático (ES):** Absorve 1 impacto direto.
     - **Cura (CU):** Recupera +1 ponto de vida (não pode ser consumida se o HP estiver cheio).

---

## 6. LIMITAÇÕES E PROBLEMAS CONHECIDOS

1. **Retratos de Personagem:** Os retratos de BoyPunk e Nilo estão carregados na memória, porém sua exibição nos cantos do HUD segue em avaliação de design pela equipe de arte.
2. **Factory Overlord:** Na Fábrica de Sucata, o Overlord é elemento cenográfico de tensão ambiental; ele não possui entidade viva, barra de HP de combate ou dano direto de colisão com projéteis.
3. **Parallax do Distrito Neon:** O efeito de profundidade é decorativo de câmera fixa (deslocamento sutil entre planos sem scroll livre de câmera horizontal).
4. **Navegadores Mobile:** O jogo possui botões virtuais na tela, mas a presente build foi otimizada e testada primordialmente para desktop (resoluções 16:9).

---

## 7. COMO REGISTRAR FEEDBACK

Por favor, utilize o arquivo `DOCUMENTACAO/FORMULARIO_FEEDBACK.csv` para reportar inconsistências, falhas ou sugestões de balanceamento/game feel, detalhando o dispositivo, personagem e passos de reprodução.
